// Dummy root entry so the Functions worker is happy.
// Actual logic is in VisitorCounter/index.js via function.json.

module.exports = {};
